
#--------------#
# Question 2.2 #
#--------------#

"""
We used a lot of "List comprehensions" here. For example,
print [a+5 for a in [1,2,3,4,5,6]]
returns: [6,7,8,9,10,11]
Each time you can replace it by
for a in [1,2,3,4,5,6]:
    print a+5
But list comprehensions are one of the reasons why Python is attractive, try it!

Also note that strings are arrays of characters, so you can index them the same way:
'Bioinformatics'[3:6] -> 'inf'
'Bioinformatics'[:-5] -> 'Bioinform' (minus means 'from the end')
'Bioinformatics'[:7]  -> 'Bioinfo'

The code is designed to work in simple situations, where for example
reads overlap only two-by-two.
"""

#reads = ["CCACAG", "CACAGA"]; l=5 # arbitrary, but need *l* inferior or equal to *min_overlap*+1
#reads = ["AAATTTGGC", "TGGCAAA", "CAAATTGCGAGT"]; l=4
reads = ["AATGT", "ATGTC", "GTCGA", "CGATT"]; l=3
#reads = ["AATGT","TGTAT","GTATG","ATGCC"]; l=3 # the example done on the board
#reads = ["AATTGCTAG","GCTAGGGCC","TTGCTAGGG","GGGCCTACT"]; l=5 # FAILS

l = 3  #

#------------------#
# Overlap function #
#------------------#
# The function from exercise 1. We will reuse it.
def overlaps(read1, read2, min_overlap):
    """If the end of read1 overlaps with at least *min_overlaps* nucleotides
    of read2, return the overlap sequence, False otherwise."""
    read_length = min(len(read1),len(read2))
    if read1 in read2: return read1 # in case one of the reads contains the other one
    if read2 in read1: return read2
    for i in xrange(read_length, min_overlap-1, -1):
        if read1[-i:] == read2[:i]:
            return read2[:i]
    return "" # small change here, because one cannot write len(False).

#------------------#
# Subseqs function #
#------------------#
def subseqs(read, l):
    """Extracts all sub-sequences of length l"""
    return [read[i:i+l] for i in xrange(len(read)-l+1)]

#----------------------#
# Build the dual graph #
#----------------------#
Vdual = [] # Vertices: all unique (l-1)-mers
for r in reads: Vdual.extend(subseqs(r,l-1))
Vdual = list(set(Vdual)) # list(set(.)) returns unique elements

Sl = [] # All l-mers
for r in reads: Sl.extend(subseqs(r,l))

"""
This would suffice with the example we gave you, but actually you
are counting twice l-mers from overlap sequences. One has to remove copies.
It is even more complicated than what is written here, especially if more than two reads
overlap in the same region. The method used here is not the one used by the real algorithm.
"""
Olaps = [overlaps(v1,v2,l) for v1 in reads for v2 in reads if v1!=v2]
copies = []
for o in Olaps: copies.extend(subseqs(o,l)) # list all l-mers contained in the overlaps between reads
for c in copies: Sl.pop(Sl.index(c)) # remove them from Sl, since they are counted twice

Edual = [] # Edges
for s in Sl:
    linked_by_s = [(v1,v2) for v1 in Vdual for v2 in Vdual if (s[:-1]==v1 and s[1:]==v2 and v1!=v2)]
    Edual.extend(linked_by_s)

print "Vertices:", Vdual
print "Sl:", Sl
print "Edges:", Edual

#--------------------------------#
# Find start and end, bind them. #
#--------------------------------#
"""
The general way to find the start and end of your contig is to look for
vertices with unequal number of outgoing and incoming edges.
You don't have to create functions, but else it can become ugly and complicated.
"""

def outgoing(vertex, edges):
    """Returns the list of edges from *edges* entering into node *vertex*."""
    return [edge for edge in edges if edge[0] == vertex]

def incoming(vertex, edges):
    """Returns the list of edges from *edges* coming from node *vertex*."""
    return [edge for edge in edges if edge[1] == vertex]

start = [v for v in Vdual if len(outgoing(v,Edual)) > len(incoming(v,Edual))] # should contain 1 element
end = [v for v in Vdual if len(outgoing(v,Edual)) < len(incoming(v,Edual))] # should contain 1 element
Edual.append((end[0], start[0]))
print "start:",start, ",\t end:",end # start and end should both have only one element.


#---------------#
# Find the path #
#---------------#
import hierholzer
cycle = hierholzer.hierholzer(Vdual, Edual)

#------------------------#
# Reconstruct the contig #
#------------------------#
istart = cycle.index(start[0]) # index of 'start' vertex in *path*
cycle = cycle[istart:]+cycle[:istart] # put 'start' at the beginning, 'end' at the end of *path*
path = cycle[:-1]
print "Eulerian path:", path # remove last element to break the cycle between start and end
contig = path[0] # begin from the 'start' vertex
for i in range(1,len(path)):
    contig = contig+path[i][-1] # add the last letter of each vertex in the path
print "Contig:",contig

"""
e.g. with l=3:
Sequence: AATGTCGATT
Reads: AATGT, ATGTC, GTCGA, CGATT
Vdual = AA, AT, TG, GT, TC, CG, TT, GA
Sl = AAT, ATG, TGT, GTC, TCG, CGA, GAT, ATT, TTG, TGA, GAC
Edual = [(AA,AT), (AT,TG), (AT,TT), (AT,GA), ...]

The graph: TG -> GT -> TC
           ^           ^
           |           |
     AA -> AT <- GA <- CG
       ^   |
        \  v             # AA-TT to close the cycle
           TT            # begin from AA, then add the last base of each vertex.
"""
